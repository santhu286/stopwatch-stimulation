# VTU 6th sem mini project
computer graphics laboratory(18csl67)
project name : STOPWATCH

# abstract
This project is about demonstration of a simple stopwatch. A stopwatch is used to measure the time inteval of an event or the amount of time that elapses between its activation and deactivation. Stopwatch consist of a second and a minute hand. Each mark on clock radius differs one unit of time,based on the hand you are reading, it can be one second or one minute. Initially both handds will be resting at 00:00. On clicking of button/key, user can change background color, start/stop the time and take reading,later it can be reset to initial position 00:00and repeat, and quit the interface.
The interface is very simple to interpret and is user friendly. The stopwatch is accurate and looks can also be changed based on user preferences. Since this uses OpenGL platform, it becomes portable.

# software requirements
Operating System : Ubuntu/Windows/Mac
Language tool : C/C++ using OpenGL
Compiler : gcc version 4.5.1 or above
Libraries : Supporting OpenGL libraries and 32 bit color resolution
Documentation : MS Word

# hardware requirements
Processor : intel i3/ryzen 3 onwards Compatible Hardware
RAM : 512Mb or above
Hard Disk : 40 Gb or more
Input device : Keyboard,mouse
Output device : Monitor

# by:
Manoj G

# reference
https://github.com/sobit-nep/opengl-analog-clock/blob/main/main.cpp
